import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertAssignments extends Panel 
{
	Button assignmentButton;
	TextField aidText,deadLineText,scoreText;
	Choice  c_idSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertAssignments() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	
	
	private void loadCourses() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM courses");
		  while (rs.next()) 
		  {
			c_idSelect.add(rs.getString("C_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	   
		c_idSelect = new Choice();
		loadCourses();
		
	    
		//Handle Reserve Button
		assignmentButton = new Button("Submit");
		assignmentButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO Assignments VALUES("   + aidText.getText()+","+ c_idSelect.getSelectedItem()  + ",' "
				  + deadLineText.getText()+"','"+scoreText.getText()+"')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		aidText = new TextField(15);
		deadLineText=new TextField(15);
		scoreText=new TextField(15);
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Assignment ID:"));
		first.add(aidText);
		first.add(new Label("Course ID:"));
		first.add(c_idSelect);
		first.add(new Label("DeadLine:"));
		first.add(deadLineText);
		first.add(new Label("Score:"));
		first.add(scoreText);

		
		Panel second = new Panel(new GridLayout(2, 1));
		second.add(assignmentButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertAssignments ina = new InsertAssignments();

		ina.buildGUI();
	}
}

