
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertCourses extends Panel 
{
	Button insertCoursesButton;
	TextField cidText, cnameText, durText, minText,statusText,priceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertCourses() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI()  
	{		
		//Handle Insert Account Button
		insertCoursesButton = new Button("Submit");
		insertCoursesButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				 Statement statement = connection.createStatement();
				  				  
				 String query= "INSERT INTO COURSES VALUES(" + cidText.getText() + ", " + "'" + cnameText.getText() + "'," + "'" + durText.getText() + "',"+"'"+minText.getText()+"'," +"'"+statusText.getText()+"',"+priceText.getText()+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		cnameText = new TextField(15);
		cidText = new TextField(15);
		durText = new TextField(15);
		minText = new TextField(15);
	    statusText = new TextField(15);
	   priceText = new TextField(15);
	

		
		errorText = new TextArea(10,40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6,2));
		first.add(new Label("Course ID:"));
		first.add(cidText);
		first.add(new Label("Name:"));
		first.add(cnameText);
		first.add(new Label("Duration:"));
		first.add(durText);
		first.add(new Label("Min_grade:"));
		first.add(minText);
		first.add(new Label("Status:"));
		first.add(statusText);
		first.add(new Label("Price:"));
		first.add(priceText);
		

		first.setBounds(125,90,300,150);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertCoursesButton);
		second.setBounds(195,290,150,100);       
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(80,410,430,300);
		setLayout(null);
	
		add(first);
		add(second);
		add(third);
	    
		setSize(500,600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertCourses course = new InsertCourses();

			
		course.buildGUI();
	}
}
