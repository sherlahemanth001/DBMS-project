
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertStudent extends Panel 
{
	Button insertStudentButton;
	TextField sidText, fnameText, lnameText,unameText, passwordText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertStudent() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI()  
	{		
		//Handle Insert Account Button
		insertStudentButton = new Button("Submit");
		insertStudentButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				 Statement statement = connection.createStatement();
				  				  
				 String query= "INSERT INTO student VALUES(" + sidText.getText() + ", " + "'" + fnameText.getText() + "'," + "'" + lnameText.getText() + "',"+"'"+unameText.getText()+"'," +"'"+passwordText.getText()+"'"+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		fnameText = new TextField(15);
		sidText = new TextField(15);
		lnameText = new TextField(15);
		unameText = new TextField(15);
		passwordText = new TextField(15);

		
		errorText = new TextArea(10,40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5,2));
		first.add(new Label("Student ID:"));
		first.add(sidText);
		first.add(new Label("FirstName:"));
		first.add(fnameText);
		first.add(new Label("LastName:"));
		first.add(lnameText);
		first.add(new Label("Username:"));
		first.add(unameText);
		first.add(new Label("Password:"));
		first.add(passwordText);
		
		first.setBounds(125,90,300,150);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertStudentButton);
		second.setBounds(195,290,150,100);       
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(80,410,430,300);
		setLayout(null);

	
		add(first);
		add(second);
		add(third);
	    
		setSize(400,180);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertStudent ins = new InsertStudent();
				

			
		ins.buildGUI();
	}
}
