import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateAssignments extends Panel 
{
	Button updateAssignmentsButton;
	List assignmentsIDList;
	TextField aidText,c_idText,deadLineText,scoreText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateAssignments()
	
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAssignments() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT A_ID  from Assignments");
		  while (rs.next()) 
		  {
			assignmentsIDList.add(rs.getString("A_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    assignmentsIDList = new List(10);
		loadAssignments();
		add(assignmentsIDList);
		
		//When a list item is selected populate the text fields
	assignmentsIDList.addItemListener(new ItemListener()
		{
		public void itemStateChanged(ItemEvent e) 
		{
			try 
			{
				rs = statement.executeQuery("SELECT * FROM Assignments");
				while (rs.next()) 
				{
					if (rs.getString("A_ID").equals(assignmentsIDList.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
					aidText.setText(rs.getString("A_ID"));
					c_idText.setText(rs.getString("C_ID"));
					deadLineText.setText(rs.getString("DeadLine"));
					scoreText.setText(rs.getString("Score"));
					
				}
			} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateAssignmentsButton = new Button("Modify");
		updateAssignmentsButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Assignments SET  DeadLine ='"+deadLineText.getText()+ "',Score = '"+scoreText.getText()+"'"+"WHERE A_id = "
					+ assignmentsIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					assignmentsIDList.removeAll();
					loadAssignments();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		aidText.setEditable(false);
		c_idText = new TextField(15);
		c_idText .setEditable(false);
		deadLineText = new TextField(15);
		scoreText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Assignment ID:"));
		first.add(aidText);
	
		first.add(new Label("Course ID:"));
		first.add(c_idText);
		
		first.add(new Label("DeadLine:"));
		first.add(deadLineText);
	
		first.add(new Label("Score:"));
		first.add(scoreText);
		
		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(updateAssignmentsButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateAssignments upa = new UpdateAssignments();
	
		upa.buildGUI();
	}
}
