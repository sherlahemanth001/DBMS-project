import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteProvider extends Panel 
{
	Button deleteProviderButton;
	List providerIDList;
	TextField pidText, pnameText, typeText, hqText,foundedText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteProvider() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadProvider() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Online_Moocs_Provider");
		  while (rs.next()) 
		  {
			providerIDList.add(rs.getString("P_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    providerIDList = new List(10);
		loadProvider();
		add(providerIDList);
		
		//When a list item is selected populate the text fields
		providerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Online_Moocs_Provider");
					while (rs.next()) 
					{
						if (rs.getString("P_ID").equals(providerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						pidText.setText(rs.getString("P_ID"));
						pnameText.setText(rs.getString("P_NAME"));
						typeText.setText(rs.getString("TYPE"));
						hqText.setText(rs.getString("HeadQuarters"));
						foundedText.setText(rs.getString("FOUNDED"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteProviderButton = new Button("Delete");
		deleteProviderButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Online_moocs_provider WHERE P_ID = "
							+ providerIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					pidText.setText(null);
					pnameText.setText(null);
					typeText.setText(null);
					hqText.setText(null);
					foundedText.setText(null);
					providerIDList.removeAll();
					loadProvider();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		pidText = new TextField(15);
		pnameText = new TextField(15);
		typeText = new TextField(15);
		hqText = new TextField(15);
		foundedText= new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Provider ID:"));
		first.add(pidText);
		pidText.setEditable(false);
		first.add(new Label("Name:"));
		first.add(pnameText);
		pnameText.setEditable(false);
		first.add(new Label("Type:"));
		first.add(typeText);
		typeText.setEditable(false);
		first.add(new Label("HQ:"));
		first.add(hqText);
		hqText.setEditable(false);
		first.add(new Label("Founded:"));
		first.add(foundedText);
		foundedText.setEditable(false);
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteProviderButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteProvider dels = new DeleteProvider();
		dels.buildGUI();
	}
}

