import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCourses extends Panel 
{
	Button updateCoursesButton;
	List coursesIDList;
	TextField cidText,cnameText, durText, minText,statusText,priceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCourses()
	
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCourses() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT C_ID FROM Courses");
		  while (rs.next()) 
		  {
			coursesIDList.add(rs.getString("C_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    coursesIDList = new List(10);
		loadCourses();
		add(coursesIDList);
		
		//When a list item is selected populate the text fields
	coursesIDList.addItemListener(new ItemListener()
		{
		public void itemStateChanged(ItemEvent e) 
		{
			try 
			{
				rs = statement.executeQuery("SELECT * FROM Courses");
				while (rs.next()) 
				{
					if (rs.getString("C_ID").equals(coursesIDList.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
					cidText.setText(rs.getString("C_ID"));
					cnameText.setText(rs.getString("C_NAME"));
					durText.setText(rs.getString("Duration"));
					minText.setText(rs.getString("Min_grade"));
					statusText.setText(rs.getString("Status"));
					priceText.setText(rs.getString("Price"));
				}
			} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateCoursesButton = new Button("Modify");
		updateCoursesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Courses "
					+ "SET c_name='" + cnameText.getText() + "', "
					+ "duration='" + durText.getText() + "', "
					+ "Min_grade ='"+ minText.getText()+"',"
					+"status ='"+ statusText.getText()+"',"
					+"price=" +priceText.getText()+ " WHERE C_id = "
					+ coursesIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					coursesIDList.removeAll();
					loadCourses();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		cnameText = new TextField(15);
		durText = new TextField(15);
		minText = new TextField(15);
		statusText=new TextField(15);
		priceText=new TextField(15);
		
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Course ID:"));
		first.add(cidText);
		first.add(new Label("CName:"));
		first.add(cnameText);
		first.add(new Label("duration:"));
		first.add(durText);
		first.add(new Label("Min_Grade:"));
		first.add(minText);
		first.add(new Label("Status:"));
		first.add(statusText);
		first.add(new Label("Price:"));
		first.add(priceText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateCoursesButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateCourses upc = new UpdateCourses();

	
		upc.buildGUI();
	}
}
