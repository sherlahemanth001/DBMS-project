import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteAssignment extends Panel 
{
	Button deleteAssignmentButton;
	List assignmentIDList;
	TextField  c_idText, aidText,deadLineText,scoreText; 
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteAssignment() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAssignment() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Assignments");
		  while (rs.next()) 
		  {
			assignmentIDList.add(rs.getString("A_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    assignmentIDList = new List(10);
		loadAssignment();
		add(assignmentIDList);
		
		//When a list item is selected populate the text fields
		assignmentIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Assignments");
					while (rs.next()) 
					{
						if (rs.getString("A_ID").equals(assignmentIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						aidText.setText(rs.getString("A_ID"));
						c_idText.setText(rs.getString("C_ID"));
						deadLineText.setText(rs.getString("DeadLine"));
						scoreText.setText(rs.getString("Score"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteAssignmentButton = new Button("Delete");
		deleteAssignmentButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM ASSIGNMENTS WHERE A_ID = "
							+ assignmentIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					aidText.setText(null);
					c_idText.setText(null);
					deadLineText.setText(null);
					scoreText.setText(null);
					
					assignmentIDList.removeAll();
					loadAssignment();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		c_idText = new TextField(15);
		deadLineText = new TextField(15);
		scoreText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Assignment ID:"));
		first.add(aidText);
		aidText.setEditable(false);
		first.add(new Label("Course ID:"));
		first.add(c_idText);
		c_idText.setEditable(false);
		first.add(new Label("DeadLine:"));
		first.add(deadLineText);
		deadLineText.setEditable(false);
		first.add(new Label("Score:"));
		first.add(scoreText);
		scoreText.setEditable(false);
		
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteAssignmentButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAssignment dela = new DeleteAssignment();
		dela.buildGUI();
	}
}



