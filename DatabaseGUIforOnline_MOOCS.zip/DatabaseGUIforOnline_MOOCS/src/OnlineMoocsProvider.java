import java.awt.*; 
import java.awt.event.*; 

class OnlineMoocsProvider extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll,l2;
	  
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  InsertProvider provide;
	  UpdateProvider upp;
	DeleteProvider delp;
	InsertCourses inc;
	UpdateCourses upc;
	DeleteCourses delc;
	InsertStudent ins;
	DeleteStudent dels;
	UpdateStudent us;
	Enroll mks;
	UpdateEnroll upe;
	DeleteEnroll dele;
	InsertAssignments ina;
	UpdateAssignments upa;
	DeleteAssignment dela;
	InsertResults inr;
	DeleteResults delr;
	UpdateResults upr;
	  
	  Panel home,welcome; 
	  
	 OnlineMoocsProvider() 
	  { 
			cardLO = new CardLayout(); 
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			l2 =new Label();
			ll.setAlignment(Label.CENTER);  
			l2.setAlignment(Label.CENTER); 
			ll.setText("Welcome to Online MOOC's Provider");
			l2.setText("All @rights are reserved");
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);
			welcome.add(l2);
			
			//create panels for each of our menu items and build them with respective components
			provide = new InsertProvider(); provide.buildGUI();
			upp = new UpdateProvider();  upp.buildGUI();
			delp = new DeleteProvider();	delp.buildGUI();
			inc = new InsertCourses();inc.buildGUI();
			upc= new UpdateCourses();upc.buildGUI();
			delc = new DeleteCourses();delc.buildGUI();
			ins = new InsertStudent();ins.buildGUI();
			dels = new DeleteStudent();dels.buildGUI();
			us= new UpdateStudent();us.buildGUI();
			mks= new Enroll();	mks.buildGUI();
			upe= new UpdateEnroll();upe.buildGUI();
			dele = new DeleteEnroll(); dele.buildGUI();
			ina = new InsertAssignments();ina.buildGUI();
			upa = new UpdateAssignments();upa.buildGUI();
			dela = new DeleteAssignment();dela.buildGUI();
			inr = new InsertResults();inr.buildGUI();
			delr = new DeleteResults();delr.buildGUI();
			upr = new UpdateResults();upr.buildGUI();
			
			
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(provide, "InsertProvider"); 
			home.add(upp, "UpdateProvider"); 
			home.add(delp, "DeleteProvider"); 
			home.add(inc,"InsertCourses");
			home.add(upc,"UpdateCourses");
			home.add(delc,"DeleteCourses");
			home.add(ins,"InsertStudent");
			home.add(dels,"DeleteStudent");
			home.add(us,"UpdateStudent");
			home.add(mks,"Enroll");
			home.add(upe,"UpdateEnroll");
			home.add(dele,"DeleteEnroll");
			home.add(ina,"InsertAssignments");
			home.add(upa,"UpdateAssignments");
			home.add(dela,"DeleteAssignment");
			home.add(inr,"InsertResults");
			home.add(delr,"DeleteResults");
			home.add(upr,"UpdateResults");
			
			
			
			
			
			//home.add(upb, "UpdateBoat"); 
			//home.add(mks, "MakeReserve"); 
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu provider = new Menu("OnlineMOOC'sProvider"); 
			MenuItem item1, item2, item3; 
			provider.add(item1 = new MenuItem("Insert Provider")); 
			provider.add(item2 = new MenuItem("View Provider")); 
			provider.add(item3 = new MenuItem("Delete Provider")); 
			mbar.add(provider);  
		 
			Menu courses = new Menu("Courses"); 
			MenuItem item4, item5, item6; 
			courses.add(item4 = new MenuItem("Insert Courses")); 
			courses.add(item5 = new MenuItem("View Courses")); 
			courses.add(item6 = new MenuItem("Delete Courses"));  
			mbar.add(courses); 
			
			Menu student = new Menu("Student"); 
			MenuItem item7, item8, item9; 
			student.add(item7 = new MenuItem("Insert Student")); 
			student.add(item8 = new MenuItem("View Student")); 
			student.add(item9 = new MenuItem("Delete Student")); 
			mbar.add(student);			
			
			Menu enroll= new Menu("Enroll"); 
			MenuItem item10, item11, item12; 
			enroll.add(item10 = new MenuItem("Insert Enroll")); 
			enroll.add(item11= new MenuItem("View Enroll")); 
			enroll.add(item12 = new MenuItem("Delete Enroll")); 
			mbar.add(enroll);
			
			Menu assignments= new Menu("Assignments"); 
			MenuItem item13, item14, item15; 
			assignments.add(item13 = new MenuItem("Insert Assignments")); 
			assignments.add(item14= new MenuItem("View Assignments")); 
			assignments.add(item15 = new MenuItem("Delete Assignment")); 
			mbar.add(assignments);
			
			Menu results= new Menu("Results"); 
			MenuItem item16, item17, item18; 
			results.add(item16 = new MenuItem("Insert Results")); 
			results.add(item17= new MenuItem("View Results")); 
			results.add(item18 = new MenuItem("Delete Results")); 
			mbar.add(results);
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this);
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
			item16.addActionListener(this);	
			item17.addActionListener(this);	
			item18.addActionListener(this);	
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Online MOOC's Provider"); 
			Color clr = new Color(50, 150, 100);
			setBackground(clr); 
			setFont(new Font("Monaco", Font.BOLD, 20)); 
			setSize(900, 1000); 
		
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Provider"))
		  {
			  
			cardLO.show(home, "InsertProvider"); 			
          }			
		 
		 else if(arg.equals("View Provider")) 
		 {
			
			cardLO.show(home, "UpdateProvider"); 			
		 }
		 
		 else if(arg.equals("Delete Provider")) 
		 {
			 
			cardLO.show(home, "DeleteProvider"); 			
		 }
		 else if(arg.equals("Insert Courses"))
		 {
			 
			 cardLO.show(home, "InsertCourses"); 
		 }
		 else if(arg.equals("Delete Courses"))
		 {
			 
			 cardLO.show(home, "DeleteCourses");
		 }
		 else if(arg.equals("View Courses"))
		 {
			
			 cardLO.show(home, "UpdateCourses");
		 }
		 else if(arg.equals("Insert Student"))
		 {
			 cardLO.show(home, "InsertStudent"); 
		 }
		 else if(arg.equals("Delete Student"))
		 {
			 cardLO.show(home, "DeleteStudent"); 
		 }
		 else if(arg.equals("View Student"))
		 {
			 cardLO.show(home, "UpdateStudent"); 
		 }
		 else if(arg.equals("Insert Enroll"))
		 {
			 cardLO.show(home, "Enroll"); 
		 }
		 else if(arg.equals("View Enroll"))
		 {
			 cardLO.show(home, "UpdateEnroll"); 
		 }
		 else if(arg.equals("Delete Enroll"))
		 {
			 cardLO.show(home, "DeleteEnroll"); 
		 }
		 else if(arg.equals("Insert Assignments"))
		 {
			 cardLO.show(home, "InsertAssignments");
		 }
		 else if(arg.equals("View Assignments"))
		 {
			 cardLO.show(home, "UpdateAssignments");
		 }

		 else if(arg.equals("Insert Results"))
		 {
			 cardLO.show(home, "InsertResults");
		 }
		 else if(arg.equals("View Results"))
		 {
			 cardLO.show(home, "UpdateResults");
		 }
		 else if(arg.equals("Delete Results"))
		 {
			 cardLO.show(home, "DeleteResults"); 
		 }
		  
	  }
	  public static void main(String  ... args)
	  {
			new OnlineMoocsProvider();	  
	  }
}