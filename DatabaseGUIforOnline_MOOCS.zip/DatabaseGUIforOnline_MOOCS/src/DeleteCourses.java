import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteCourses extends Panel 
{
	Button deleteCoursesButton;
	List coursesIDList;
	TextField cidText, cnameText, durText, minText,statusText,priceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteCourses() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCourses() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM courses");
		  while (rs.next()) 
		  {
			coursesIDList.add(rs.getString("C_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    coursesIDList = new List(10);
		loadCourses();
		add(coursesIDList);
		
		//When a list item is selected populate the text fields
		coursesIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM courses");
					while (rs.next()) 
					{
						if (rs.getString("C_ID").equals(coursesIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("C_ID"));
						cnameText.setText(rs.getString("C_NAME"));
						durText.setText(rs.getString("DURATION"));
						minText.setText(rs.getString("Min_grade"));
						statusText.setText(rs.getString("STATUS"));
						priceText.setText(rs.getString("PRICE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteCoursesButton = new Button("Delete");
		deleteCoursesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM courses WHERE C_ID = "
							+ coursesIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidText.setText(null);
					cnameText.setText(null);
					durText.setText(null);
					minText.setText(null);
					statusText.setText(null);
					priceText.setText(null);
					coursesIDList.removeAll();
					loadCourses();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cnameText = new TextField(15);
		durText = new TextField(15);
		minText = new TextField(15);
		statusText= new TextField(15);
		priceText= new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Course ID:"));
		first.add(cidText);
		cidText.setEditable(false);
		first.add(new Label("Name:"));
		first.add(cnameText);
		cnameText.setEditable(false);
		first.add(new Label("Duration:"));
		first.add(durText);
		durText.setEditable(false);
		first.add(new Label("Min_grade:"));
		first.add(minText);
		minText.setEditable(false);
		first.add(new Label("Status:"));
		first.add(statusText);
		statusText.setEditable(false);
		first.add(new Label("Price:"));
		first.add(priceText);
		priceText.setEditable(false);
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteCoursesButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteCourses delc = new DeleteCourses();
		delc.buildGUI();
	}
}

