import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateResults extends Panel 
{
	Button updateResultsButton;
	List resultsIDList;
	TextField scrText,gradeText;
	TextField s_idText, c_idText,a_idText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateResults()
	
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadResults() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM RESULTS");
		  while (rs.next()) 
		  {
			resultsIDList.add(rs.getString("S_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    resultsIDList = new List(10);
		loadResults();
		add(resultsIDList);
		
		//When a list item is selected populate the text fields
	resultsIDList.addItemListener(new ItemListener()
		{
		public void itemStateChanged(ItemEvent e) 
		{
			try 
			{
				rs = statement.executeQuery("SELECT * FROM Results");
				while (rs.next()) 
				{
					if (rs.getString("S_ID").equals(resultsIDList.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
					s_idText.setText(rs.getString("S_ID"));
					c_idText.setText(rs.getString("C_ID"));
					a_idText.setText(rs.getString("A_id"));
					scrText.setText(rs.getString("SCORE"));
					gradeText.setText(rs.getString("GRADE"));
					
					
				}
			} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateResultsButton = new Button("Modify");
		updateResultsButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Results SET C_id=" +c_idText.getText()+", A_ID ="+a_idText.getText()+", SCORE ='"+scrText.getText()+"', GRADE = '"+gradeText.getText()+ "' WHERE S_id = "
					+ resultsIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					resultsIDList.removeAll();
					loadResults();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		s_idText = new TextField(15);
		s_idText.setEditable(false);
		c_idText = new TextField(15);
		c_idText .setEditable(false);
		a_idText = new TextField(15);
		a_idText.setEditable(false);
		scrText = new TextField(15);
		gradeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Student ID:"));
		first.add(s_idText);
		
		first.add(new Label("Course ID:"));
		first.add(c_idText);
		
		first.add(new Label("Assignment ID:"));
		first.add(a_idText);
		
		first.add(new Label("SCORE:"));
		first.add(scrText);
		
		first.add(new Label("Grade:"));
		first.add(gradeText);
	
		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(updateResultsButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateResults upr = new UpdateResults();
		upr.buildGUI();
	}
}
