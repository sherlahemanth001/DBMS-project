import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteEnroll extends Panel 
{
	Button deleteEnrollButton;
	List enrollIDList;
	TextField s_idText, c_idText, yearText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteEnroll() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadEnroll() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM ENROLLS");
		  while (rs.next()) 
		  {
			enrollIDList.add(rs.getString("S_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    enrollIDList = new List(10);
		loadEnroll();
		add(enrollIDList);
		
		//When a list item is selected populate the text fields
		enrollIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM enrolls");
					while (rs.next()) 
					{
						if (rs.getString("S_ID").equals(enrollIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						s_idText.setText(rs.getString("S_ID"));
						c_idText.setText(rs.getString("C_ID"));
						yearText.setText(rs.getString("YEAR"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteEnrollButton = new Button("Delete");
		deleteEnrollButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM ENROLLS WHERE S_ID = "
							+ enrollIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					s_idText.setText(null);
					c_idText.setText(null);
					yearText.setText(null);
					
					enrollIDList.removeAll();
					loadEnroll();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		s_idText = new TextField(15);
		c_idText = new TextField(15);
		yearText = new TextField(15);
	
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Student ID:"));
		first.add(s_idText);
		s_idText.setEditable(false);
		first.add(new Label("Course ID:"));
		first.add(c_idText);
		c_idText.setEditable(false);
		first.add(new Label("Year:"));
		first.add(yearText);
		yearText.setEditable(false);
		
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteEnrollButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteEnroll dele = new DeleteEnroll();
		dele.buildGUI();
	}
}



