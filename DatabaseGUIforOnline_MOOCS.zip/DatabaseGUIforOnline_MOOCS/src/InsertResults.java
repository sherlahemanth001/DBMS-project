import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertResults extends Panel 
{
	Button resultsButton;
	TextField scrText,gradeText;
	Choice s_idSelect, c_idSelect,a_idSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertResults() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hemanth","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudent() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM STUDENT");
		  while (rs.next()) 
		  {
			s_idSelect.add(rs.getString("S_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadCourses() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM courses");
		  while (rs.next()) 
		  {
			c_idSelect.add(rs.getString("C_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadAssignments() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM ASSIGNMENTS");
		  while (rs.next()) 
		  {
			a_idSelect.add(rs.getString("A_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    s_idSelect = new Choice();
		loadStudent();
		
		c_idSelect = new Choice();
		loadCourses();
		
		a_idSelect = new Choice();
		loadAssignments();
		
	    
		//Handle Reserve Button
		resultsButton = new Button("Submit");
		resultsButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO Results VALUES(" + s_idSelect.getSelectedItem() + ", " + c_idSelect.getSelectedItem()+ ",'" + scrText.getText() + "','" + gradeText.getText() + "',"+a_idSelect.getSelectedItem() +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		scrText = new TextField(15);
		gradeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Student ID:"));
		first.add(s_idSelect);
		first.add(new Label("Course ID:"));
		first.add(c_idSelect);
		first.add(new Label("Assignment ID:"));
		first.add(a_idSelect);
		first.add(new Label("Score:"));
		first.add(scrText);
		first.add(new Label("Grade:"));
		first.add(gradeText);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(resultsButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertResults inr = new InsertResults();

		inr.buildGUI();
	}
}

